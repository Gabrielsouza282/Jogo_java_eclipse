package jogo.space;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.border.LineBorder;

public class Main extends JFrame {

	/**
	 * Serial gerado automaticamente apenas para efeito de serialização
	 */
	private static final long serialVersionUID = 1L;

	public Main() {
		construirMenuBar();
		construirFase();
		configurarTela();
	}

	public static void main(String[] args) {
		new Main();
	}

	private JMenuBar construirMenuBar() {
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(Color.WHITE);
		menuBar.setBorder(new LineBorder(Color.white));
		JMenu menu = new JMenu("Amar � a Arte de Cuidar");
		JMenuItem sobre = new JMenuItem("Combate Ao Covid-19");
		sobre.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane
						.showMessageDialog(
								null,
								"Lave com frequ�ncia as m�os at� a altura dos punhos, com �gua e sab�o, ou ent�o higienize com �lcool em gel 70%"
								+ "\n\n Ao tossir ou espirrar, cubra nariz e boca com len�o ou com o bra�o, e n�o com as m�os."
								+ "\n\n Evite tocar olhos, nariz e boca com as m�os n�o lavadas. "
								+"\n\n Mantenha uma dist�ncia m�nima de cerca de 2 metros de qualquer pessoa tossindo ou espirrando. "
								+"\n\n Higienize com frequ�ncia o celular e os brinquedos das crian�as.  "
								+"\n\n N�o compartilhe objetos de uso pessoal, como talheres, toalhas, pratos e copos. "
								+"\n\n Mantenha os ambientes limpos e bem ventilados. "
								+"\n\n Durma bem e tenha uma alimenta��o saud�vel."
					
								+"\n\n Utilize m�scaras caseiras ou artesanais feitas de tecido em situa��es de sa�da de sua resid�ncia. "
								
                                + "\n\n Disque Sa�de 136 Para maiores informa��es. "
								
                                
                                + "\n\n Desenvolvido por Raimundo, Regivaldo,Julio,Leonardo. Alunos Da UniDrummond. "
								
								+ "\n\nVersão 1.0 - 2020",
								"Orienta��es sobre a prenven��o do Covid-19", JOptionPane.INFORMATION_MESSAGE);
			}
		});

		JMenuItem sair = new JMenuItem("Sair");
		sair.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);

			}
		});

		menu.add(sobre);
		menu.add(new JSeparator());
		menu.add(sair);
		menuBar.add(menu);
		setJMenuBar(menuBar);

		return menuBar;
	}

	private JPanel construirFase() {
		Fase fase = new Fase();
		add(fase);
		return fase;
	}

	private void configurarTela() {
		setSize(558, 450);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
		setTitle("Detonando o Coronavirus");
	}
}
