# AlienTrix

O projeto AlienTrix é um jogo bem simples construído na linguagem Java e que foi implementado em 2012. 

A ideia original do projeto era estudar o desenvolvimento de jogos. Certo dia coloquei um vídeo no [Youtube](https://www.youtube.com/watch?v=SQK7QYAdFSk) e disponibilizei o código-fonte para quem tivesse o interesse em aprender a criar jogos sem o uso de Game Engines. Recebi vários e-mails da galera pedindo para colocar sons, multiplayer etc. Como eu ainda estava na faculdade, consequentemente não tinha muito tempo para me dedicar a esse projeto. 

Agora o projeto está aqui no Github e quem tiver interesse em dar continuidade, fique a vontade para criar seus Forks. 

![Imagem do jogo](/src/res/print-alientrix.png?raw=true "PrintScreen do jogo")

# Onde faço o download para jogar?

Na área Releases, cada tag tem o link do .jar do projeto. Basta baixar, extrair e executar :)

# Planos de um MMORPG

Tenho planos de criar um MMORPG. Quem tiver interesse em participar, pode entrar em contato comigo no fernandogalloro@gmail.com ou fernandort@live.com






